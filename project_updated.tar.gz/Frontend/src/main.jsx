/**
 * main.jsx — The very first file React loads.
 *
 * Mounts the React app into the real DOM's <div id="root"> in index.html.
 *
 * Everything is wrapped in providers so their values are available
 * to every component in the tree. Order matters:
 *   ThemeProvider  → wraps everything (MUI needs the theme)
 *   AuthProvider   → wraps SocketProvider (socket may need auth state)
 *   SocketProvider → wraps App (all pages/components can access socket)
 */

import React from "react";
import ReactDOM from "react-dom/client";
import { ThemeProvider, CssBaseline } from "@mui/material";
import { BrowserRouter } from "react-router-dom";

import App from "./App";
import theme from "./theme";
import { AuthProvider } from "./context/AuthContext";
import { SocketProvider } from "./context/SocketContext";

// Inter font via @fontsource (self-hosted — no Google Fonts CDN dependency)
import "@fontsource/inter/400.css";
import "@fontsource/inter/600.css";
import "@fontsource/inter/700.css";
import "@fontsource/inter/800.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ThemeProvider theme={theme}>
      {/* CssBaseline = MUI's CSS reset. Normalizes browser defaults across Chrome/Firefox/Safari */}
      <CssBaseline />
      <BrowserRouter>
        <AuthProvider>
          <SocketProvider>
            <App />
          </SocketProvider>
        </AuthProvider>
      </BrowserRouter>
    </ThemeProvider>
  </React.StrictMode>
);
