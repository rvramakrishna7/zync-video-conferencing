/**
 * pages/Landing.jsx — The home page.
 *
 * What happens here:
 *  1. User sees the Zync brand + tagline
 *  2. They can either: Create a new room OR enter a room code to join
 *  3. If they're already logged in, "Create Room" hits the API directly
 *  4. If not logged in, we redirect them to login first
 *
 * MUI components used:
 *  Box       → generic div with sx prop styling
 *  Container → centers content with max-width
 *  Typography → all text (replaces h1, p, span)
 *  Button    → styled buttons
 *  TextField → the room code input
 *  Stack     → flexbox layout helper (replaces most flex divs)
 */

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Container,
  Typography,
  Button,
  TextField,
  Stack,
  Chip,
  Divider,
  Alert,
  CircularProgress,
} from "@mui/material";
import VideoCallIcon from "@mui/icons-material/VideoCall";
import MeetingRoomIcon from "@mui/icons-material/MeetingRoom";
import BoltIcon from "@mui/icons-material/Bolt";
import GroupsIcon from "@mui/icons-material/Groups";
import AutoAwesomeIcon from "@mui/icons-material/AutoAwesome";

import { useAuth } from "../context/AuthContext";
import { roomAPI } from "../services/api";

const Landing = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();

  const [roomCode, setRoomCode] = useState("");
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");

  // ── Create a new room ──────────────────────────────────────────────────────

  const handleCreateRoom = async () => {
    if (!isAuthenticated) {
      navigate("/login?redirect=create");
      return;
    }

    setCreating(true);
    setError("");

    try {
      const { data } = await roomAPI.create({ title: `${user.name}'s Meeting` });
      // Navigate to the room — React Router handles the URL change
      navigate(`/room/${data.room.roomCode}`);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to create room. Try again.");
    } finally {
      setCreating(false);
    }
  };

  // ── Join an existing room ──────────────────────────────────────────────────

  const handleJoinRoom = () => {
    const code = roomCode.trim();
    if (!code) {
      setError("Please enter a room code");
      return;
    }
    navigate(`/room/${code}`);
  };

  // Allow pressing Enter in the room code input to join
  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleJoinRoom();
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        background: "radial-gradient(ellipse at top, #1a0533 0%, #0A0A0F 60%)",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* ── Navbar ────────────────────────────────────────────────────── */}
      <Box
        component="nav"
        sx={{
          px: { xs: 3, md: 6 },
          py: 2.5,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderBottom: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        {/* Logo */}
        <Stack direction="row" alignItems="center" spacing={1}>
          <Box
            sx={{
              width: 36,
              height: 36,
              borderRadius: "10px",
              background: "linear-gradient(135deg, #7C3AED, #06B6D4)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Typography sx={{ fontWeight: 800, fontSize: "1.1rem", color: "#fff" }}>
              Z
            </Typography>
          </Box>
          <Typography variant="h6" sx={{ fontWeight: 800, letterSpacing: "-0.02em" }}>
            Zync
          </Typography>
        </Stack>

        {/* Nav actions */}
        <Stack direction="row" spacing={1.5} alignItems="center">
          {isAuthenticated ? (
            <>
              <Typography variant="body2" color="text.secondary">
                Hey, {user?.name?.split(" ")[0]} 👋
              </Typography>
              <Button variant="contained" size="small" onClick={handleCreateRoom}>
                New Meeting
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="text"
                color="inherit"
                onClick={() => navigate("/login")}
                sx={{ color: "text.secondary" }}
              >
                Sign in
              </Button>
              <Button variant="contained" size="small" onClick={() => navigate("/register")}>
                Get started
              </Button>
            </>
          )}
        </Stack>
      </Box>

      {/* ── Hero Section ──────────────────────────────────────────────── */}
      <Container maxWidth="md" sx={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", py: 8 }}>
        
        {/* Badge */}
        <Box sx={{ display: "flex", justifyContent: "center", mb: 4 }}>
          <Chip
            icon={<BoltIcon sx={{ fontSize: 16 }} />}
            label="AI-powered meeting summaries"
            size="small"
            sx={{
              background: "rgba(124, 58, 237, 0.15)",
              border: "1px solid rgba(124, 58, 237, 0.4)",
              color: "#9F67FF",
              fontWeight: 600,
              px: 1,
            }}
          />
        </Box>

        {/* Main heading */}
        <Typography
          variant="h1"
          align="center"
          sx={{
            fontSize: { xs: "2.8rem", md: "4.5rem" },
            fontWeight: 800,
            lineHeight: 1.1,
            mb: 3,
            letterSpacing: "-0.03em",
          }}
        >
          Video calls that{" "}
          <Box
            component="span"
            sx={{
              background: "linear-gradient(135deg, #7C3AED, #06B6D4)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            actually sync
          </Box>
        </Typography>

        <Typography
          variant="h6"
          align="center"
          color="text.secondary"
          sx={{ fontWeight: 400, mb: 6, maxWidth: 520, mx: "auto", lineHeight: 1.7 }}
        >
          Create a room, share the link, vibe in. AI writes your meeting notes so you don't have to.
        </Typography>

        {/* ── Action Card ───────────────────────────────────────────────── */}
        <Box
          sx={{
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 4,
            p: { xs: 3, md: 4 },
            backdropFilter: "blur(20px)",
          }}
        >
          {error && (
            <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }} onClose={() => setError("")}>
              {error}
            </Alert>
          )}

          <Stack
            direction={{ xs: "column", sm: "row" }}
            spacing={2}
            alignItems={{ xs: "stretch", sm: "flex-start" }}
          >
            {/* Create room button */}
            <Button
              variant="contained"
              size="large"
              startIcon={creating ? <CircularProgress size={18} color="inherit" /> : <VideoCallIcon />}
              onClick={handleCreateRoom}
              disabled={creating}
              sx={{ flex: 1, py: 1.8, fontSize: "1rem" }}
            >
              {creating ? "Creating..." : "Start a meeting"}
            </Button>

            {/* Divider with OR */}
            <Stack direction={{ xs: "row", sm: "column" }} alignItems="center" sx={{ px: { sm: 1 } }}>
              <Divider sx={{ flex: 1, borderColor: "rgba(255,255,255,0.1)" }} />
              <Typography variant="caption" color="text.secondary" sx={{ px: 1.5, py: { sm: 1 }, whiteSpace: "nowrap" }}>
                or
              </Typography>
              <Divider sx={{ flex: 1, borderColor: "rgba(255,255,255,0.1)" }} />
            </Stack>

            {/* Join via code */}
            <Stack direction="row" spacing={1} sx={{ flex: 1.5 }}>
              <TextField
                placeholder="Enter room code"
                value={roomCode}
                onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                onKeyDown={handleKeyDown}
                size="small"
                sx={{ flex: 1 }}
                inputProps={{ style: { letterSpacing: "0.1em", fontWeight: 600 } }}
              />
              <Button
                variant="outlined"
                onClick={handleJoinRoom}
                startIcon={<MeetingRoomIcon />}
                sx={{
                  borderColor: "rgba(124,58,237,0.5)",
                  color: "primary.light",
                  "&:hover": { borderColor: "primary.main", background: "rgba(124,58,237,0.08)" },
                  whiteSpace: "nowrap",
                  py: 1.2,
                }}
              >
                Join
              </Button>
            </Stack>
          </Stack>
        </Box>

        {/* ── Feature Pills ──────────────────────────────────────────────── */}
        <Stack
          direction="row"
          justifyContent="center"
          flexWrap="wrap"
          gap={1.5}
          sx={{ mt: 5 }}
        >
          {[
            { icon: <GroupsIcon sx={{ fontSize: 16 }} />, label: "Up to 50 participants" },
            { icon: <AutoAwesomeIcon sx={{ fontSize: 16 }} />, label: "AI meeting summary" },
            { icon: <BoltIcon sx={{ fontSize: 16 }} />, label: "Instant join via link" },
          ].map(({ icon, label }) => (
            <Chip
              key={label}
              icon={icon}
              label={label}
              size="small"
              sx={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "text.secondary",
                fontWeight: 500,
              }}
            />
          ))}
        </Stack>
      </Container>
    </Box>
  );
};

export default Landing;
