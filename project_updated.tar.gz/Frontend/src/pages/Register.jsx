/**
 * pages/Register.jsx — New user sign up.
 *
 * Same pattern as Login — controlled form, API call, store token.
 * Extra field: name. Extra validation: password confirmation.
 */

import { useState } from "react";
import { useNavigate, Link as RouterLink } from "react-router-dom";
import {
  Box, Container, Typography, TextField, Button,
  Stack, Divider, Alert, CircularProgress,
  InputAdornment, IconButton,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import GoogleIcon from "@mui/icons-material/Google";

import { useAuth } from "../context/AuthContext";
import { authAPI } from "../services/api";

const Register = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    if (error) setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (form.password !== form.confirmPassword) {
      setError("Passwords don't match");
      return;
    }

    if (form.password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const { data } = await authAPI.register({
        name: form.name,
        email: form.email,
        password: form.password,
      });
      login(data.token, data.user);
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        background: "radial-gradient(ellipse at top, #1a0533 0%, #0A0A0F 60%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        px: 2,
        py: 4,
      }}
    >
      <Container maxWidth="sm">
        <Stack alignItems="center" mb={4}>
          <Box
            sx={{
              width: 48, height: 48, borderRadius: "14px",
              background: "linear-gradient(135deg, #7C3AED, #06B6D4)",
              display: "flex", alignItems: "center", justifyContent: "center", mb: 2,
            }}
          >
            <Typography sx={{ fontWeight: 800, fontSize: "1.5rem", color: "#fff" }}>Z</Typography>
          </Box>
          <Typography variant="h4" fontWeight={700} letterSpacing="-0.02em">Create your account</Typography>
          <Typography variant="body2" color="text.secondary" mt={0.5}>Start syncing in seconds</Typography>
        </Stack>

        <Box
          sx={{
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 4,
            p: { xs: 3, sm: 4 },
          }}
        >
          {error && (
            <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>{error}</Alert>
          )}

          <Button
            fullWidth variant="outlined"
            startIcon={<GoogleIcon />}
            sx={{
              mb: 3, borderColor: "rgba(255,255,255,0.15)", color: "text.primary",
              "&:hover": { borderColor: "rgba(255,255,255,0.3)", background: "rgba(255,255,255,0.04)" },
              py: 1.4,
            }}
          >
            Continue with Google
          </Button>

          <Divider sx={{ mb: 3, "&::before, &::after": { borderColor: "rgba(255,255,255,0.08)" } }}>
            <Typography variant="caption" color="text.secondary">or with email</Typography>
          </Divider>

          <Box component="form" onSubmit={handleSubmit}>
            <Stack spacing={2.5}>
              <TextField
                label="Full name" name="name" value={form.name}
                onChange={handleChange} required fullWidth autoFocus
              />
              <TextField
                label="Email" name="email" type="email" value={form.email}
                onChange={handleChange} required fullWidth
              />
              <TextField
                label="Password" name="password"
                type={showPassword ? "text" : "password"}
                value={form.password} onChange={handleChange}
                required fullWidth helperText="At least 6 characters"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPassword(p => !p)} edge="end" size="small" sx={{ color: "text.secondary" }}>
                        {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              <TextField
                label="Confirm password" name="confirmPassword"
                type={showPassword ? "text" : "password"}
                value={form.confirmPassword} onChange={handleChange}
                required fullWidth
                error={form.confirmPassword.length > 0 && form.password !== form.confirmPassword}
                helperText={
                  form.confirmPassword.length > 0 && form.password !== form.confirmPassword
                    ? "Passwords don't match" : ""
                }
              />

              <Button
                type="submit" variant="contained" fullWidth size="large"
                disabled={loading || !form.name || !form.email || !form.password}
                sx={{ py: 1.6, mt: 1 }}
              >
                {loading ? <CircularProgress size={22} color="inherit" /> : "Create account"}
              </Button>
            </Stack>
          </Box>
        </Box>

        <Typography align="center" variant="body2" color="text.secondary" mt={3}>
          Already have an account?{" "}
          <RouterLink to="/login" style={{ color: "#9F67FF", textDecoration: "none", fontWeight: 600 }}>
            Sign in
          </RouterLink>
        </Typography>
      </Container>
    </Box>
  );
};

export default Register;
