/**
 * pages/Login.jsx
 *
 * Handles two flows:
 *  1. Email + password login (local auth)
 *  2. "Continue with Google" button (Google OAuth)
 *
 * After login, checks if there's a ?redirect= param in the URL
 * (e.g. /login?redirect=create) and navigates there instead of home.
 */

import { useState } from "react";
import { useNavigate, Link as RouterLink, useSearchParams } from "react-router-dom";
import {
  Box,
  Container,
  Typography,
  TextField,
  Button,
  Stack,
  Divider,
  Alert,
  CircularProgress,
  IconButton,
  InputAdornment,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import GoogleIcon from "@mui/icons-material/Google";

import { useAuth } from "../context/AuthContext";
import { authAPI } from "../services/api";

const Login = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { login } = useAuth();

  const [form, setForm] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Single handler for all input changes — "computed property name" pattern
  // e.target.name tells us which field changed (email or password)
  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    if (error) setError(""); // clear error when user starts typing again
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // prevent browser's default form page-reload behavior
    setLoading(true);
    setError("");

    try {
      const { data } = await authAPI.login(form);
      login(data.token, data.user); // store token + update global auth state

      // Redirect: if they came from /login?redirect=create, go create a room
      const redirect = searchParams.get("redirect");
      navigate(redirect === "create" ? "/" : "/");
    } catch (err) {
      setError(err.response?.data?.message || "Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        background: "radial-gradient(ellipse at top, #1a0533 0%, #0A0A0F 60%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        px: 2,
      }}
    >
      <Container maxWidth="sm">
        {/* Logo + heading */}
        <Stack alignItems="center" mb={4}>
          <Box
            sx={{
              width: 48,
              height: 48,
              borderRadius: "14px",
              background: "linear-gradient(135deg, #7C3AED, #06B6D4)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              mb: 2,
            }}
          >
            <Typography sx={{ fontWeight: 800, fontSize: "1.5rem", color: "#fff" }}>Z</Typography>
          </Box>
          <Typography variant="h4" fontWeight={700} letterSpacing="-0.02em">
            Welcome back
          </Typography>
          <Typography variant="body2" color="text.secondary" mt={0.5}>
            Sign in to your Zync account
          </Typography>
        </Stack>

        {/* Card */}
        <Box
          sx={{
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 4,
            p: { xs: 3, sm: 4 },
          }}
        >
          {error && (
            <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>
              {error}
            </Alert>
          )}

          {/* Google OAuth button */}
          <Button
            fullWidth
            variant="outlined"
            startIcon={<GoogleIcon />}
            sx={{
              mb: 3,
              borderColor: "rgba(255,255,255,0.15)",
              color: "text.primary",
              "&:hover": { borderColor: "rgba(255,255,255,0.3)", background: "rgba(255,255,255,0.04)" },
              py: 1.4,
            }}
          >
            Continue with Google
          </Button>

          <Divider sx={{ mb: 3, "&::before, &::after": { borderColor: "rgba(255,255,255,0.08)" } }}>
            <Typography variant="caption" color="text.secondary">
              or with email
            </Typography>
          </Divider>

          {/* Form */}
          <Box component="form" onSubmit={handleSubmit}>
            <Stack spacing={2.5}>
              <TextField
                label="Email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                required
                fullWidth
                autoComplete="email"
                autoFocus
              />

              <TextField
                label="Password"
                name="password"
                type={showPassword ? "text" : "password"}
                value={form.password}
                onChange={handleChange}
                required
                fullWidth
                autoComplete="current-password"
                InputProps={{
                  // InputProps lets you add elements inside the input field
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowPassword((prev) => !prev)}
                        edge="end"
                        size="small"
                        sx={{ color: "text.secondary" }}
                      >
                        {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />

              <Button
                type="submit"
                variant="contained"
                fullWidth
                size="large"
                disabled={loading || !form.email || !form.password}
                sx={{ py: 1.6, mt: 1 }}
              >
                {loading ? <CircularProgress size={22} color="inherit" /> : "Sign in"}
              </Button>
            </Stack>
          </Box>
        </Box>

        {/* Footer link */}
        <Typography align="center" variant="body2" color="text.secondary" mt={3}>
          Don't have an account?{" "}
          <RouterLink
            to="/register"
            style={{ color: "#9F67FF", textDecoration: "none", fontWeight: 600 }}
          >
            Create one free
          </RouterLink>
        </Typography>
      </Container>
    </Box>
  );
};

export default Login;
