/**
 * theme.js — Zync's global Material UI theme.
 *
 * WHY a custom theme?
 * MUI components use a theme system under the hood. Every Button, Card,
 * TextField etc. reads from this theme for colors, fonts, border radius.
 * Define it once here → consistent design everywhere automatically.
 *
 * This is also what makes it look like YOUR app, not a generic MUI template.
 * Interviewers notice when someone has a real design system vs default blue MUI.
 */

import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    mode: "dark", // dark mode by default — fits the GenZ video call vibe

    primary: {
      main: "#7C3AED",      // violet — Zync's brand color
      light: "#9F67FF",
      dark: "#5B21B6",
      contrastText: "#FFFFFF",
    },

    secondary: {
      main: "#06B6D4",      // cyan — accent for reactions, highlights
      light: "#38BDF8",
      dark: "#0284C7",
    },

    background: {
      default: "#0A0A0F",   // near-black — deep dark background
      paper: "#13131A",     // slightly lighter for cards, modals
    },

    text: {
      primary: "#F1F5F9",
      secondary: "#94A3B8",
    },

    error: { main: "#EF4444" },
    success: { main: "#10B981" },
    warning: { main: "#F59E0B" },

    // Custom color tokens for the video call UI
    // Access in components via: theme.palette.video.muted etc.
    video: {
      muted: "#EF4444",       // red when mic/cam is off
      active: "#10B981",      // green when on
      controlsBg: "rgba(0,0,0,0.7)",
    },
  },

  typography: {
    fontFamily: "'Inter', 'Roboto', sans-serif",

    h1: { fontWeight: 800, letterSpacing: "-0.02em" },
    h2: { fontWeight: 700, letterSpacing: "-0.01em" },
    h3: { fontWeight: 700 },
    h4: { fontWeight: 600 },
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },

    button: {
      fontWeight: 600,
      textTransform: "none", // MUI uppercases buttons by default — we don't want that
      letterSpacing: "0.01em",
    },
  },

  shape: {
    borderRadius: 12, // MUI default is 4px — we want rounder, more modern feel
  },

  components: {
    // Override default styles for specific MUI components globally

    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          padding: "10px 24px",
          fontSize: "0.95rem",
        },
        containedPrimary: {
          background: "linear-gradient(135deg, #7C3AED 0%, #5B21B6 100%)",
          boxShadow: "0 4px 20px rgba(124, 58, 237, 0.4)",
          "&:hover": {
            background: "linear-gradient(135deg, #9F67FF 0%, #7C3AED 100%)",
            boxShadow: "0 6px 25px rgba(124, 58, 237, 0.6)",
          },
        },
      },
    },

    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            borderRadius: 10,
            backgroundColor: "rgba(255,255,255,0.04)",
            "&:hover .MuiOutlinedInput-notchedOutline": {
              borderColor: "#7C3AED",
            },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor: "#7C3AED",
              borderWidth: 2,
            },
          },
        },
      },
    },

    MuiCard: {
      styleOverrides: {
        root: {
          backgroundImage: "none",
          border: "1px solid rgba(255,255,255,0.07)",
          borderRadius: 16,
        },
      },
    },

    MuiChip: {
      styleOverrides: {
        root: { borderRadius: 8 },
      },
    },
  },
});

export default theme;
