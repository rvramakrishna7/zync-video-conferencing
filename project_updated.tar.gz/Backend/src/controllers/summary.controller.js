/**
 * controllers/summary.controller.js — Generates AI meeting summary via Claude.
 *
 * ─── How this works ───────────────────────────────────────────────────────────
 *
 * When the host ends the meeting:
 *  1. Frontend sends the chat transcript (array of "name: message" strings)
 *  2. We build a prompt and send it to Claude via the Anthropic SDK
 *  3. Claude returns a structured bullet-point summary
 *  4. We save it to the Room document and return it
 *
 * ─── Why Claude for this? ─────────────────────────────────────────────────────
 *
 * Meeting transcripts are messy — people go off-topic, use shorthand,
 * have multiple threads at once. Claude is good at finding the signal
 * in the noise and structuring it into useful action items.
 */

import Anthropic from "@anthropic-ai/sdk";
import Room from "../models/Room.model.js";

// Initialize the Anthropic client — reads ANTHROPIC_API_KEY from process.env automatically
const anthropic = new Anthropic();

export const generateSummary = async (req, res, next) => {
  try {
    const { transcript } = req.body; // array of "name: message" strings
    const { roomCode } = req.params;

    const room = await Room.findOne({ roomCode });
    if (!room) {
      return res.status(404).json({ success: false, message: "Room not found" });
    }

    // If there's nothing to summarize
    if (!transcript || transcript.length === 0) {
      const fallback = "No chat messages were recorded during this meeting.";
      room.summary = fallback;
      await room.save();
      return res.json({ success: true, summary: fallback });
    }

    const transcriptText = transcript.join("\n");

    /**
     * The prompt matters a lot — we're specific about the output format
     * so the summary is always structured and useful, not a wall of text.
     *
     * We include the room title and participant count as context.
     */
    const prompt = `You are a professional meeting assistant. Analyze the following chat transcript from a video meeting called "${room.title}" and create a concise, structured summary.

Chat Transcript:
${transcriptText}

Please provide a summary with these sections (use emoji bullets):
📋 **Key Discussion Points** — main topics covered
✅ **Action Items** — tasks or follow-ups mentioned
💡 **Decisions Made** — any conclusions reached
👥 **Participants** — who was actively involved in the discussion

Keep it concise and professional. If a section has nothing to report, skip it.`;

    // Call the Claude API
    const message = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1024,
      messages: [{ role: "user", content: prompt }],
    });

    // Extract the text from Claude's response
    const summary = message.content[0].type === "text"
      ? message.content[0].text
      : "Summary could not be generated.";

    // Persist the summary on the room document
    room.summary = summary;
    await room.save();

    res.json({ success: true, summary });
  } catch (error) {
    // Don't crash the app if Claude API is down — return a graceful fallback
    console.error("Summary generation failed:", error.message);
    res.status(500).json({
      success: false,
      summary: "AI summary is temporarily unavailable.",
      message: error.message,
    });
  }
};
